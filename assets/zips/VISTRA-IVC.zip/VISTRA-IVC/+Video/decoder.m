classdef decoder < JPEG.decoder
%VIDEO.DECODER UNIMPLEMENTED
%   UNIMPLEMENTED
%
% Copyright 2011, Stephen Ierodiaconou, University of Bristol.

   properties
   end

   methods
   end
end 
