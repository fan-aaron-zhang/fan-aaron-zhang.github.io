%   TEST_PVM(): test function for PVMVideo()
%
%               TEST_PVM calls PVMVideos() and generates quality indices
%   Output: 
%               PVM - (all frame-level PVM indices)
%               PVM_dB -  sequence level index - PVM_dB);
%
%   Disclaimer:
%
%       It is provided for educational/research purpose only.
%       If you find the software useful, please consider cite our paper.
%
%       "A Perception-based Hybrid Model for Video Quality Assessment"
%       Fan Zhang and David Bull
%       IEEE Transactions on Circuits and Systems for Video Technology
%       June, 2016
%
%   Contact:
%       Fan.Zhang@bristol.ac.uk, http://seis.bris.ac.uk/~eexfz/
%       Dave.Bull@bristol.ac.uk, http://www.bristol.ac.uk/engineering/people/david-r-bull/index.html
%       University of Bristol
%
%   Copyright 2016 VI-Lab, University of Bristol.
%   Date: June 2016

function TEST_PVM()

params = initParams();
[PVM] = PVMVideo(params);
PVM_dB = 20 *log10(255./sqrt(mean(PVM(:))))

rmdir(params.workPath,'s');

function [params] = initParams()

% The input videos should have at least 5 frames;

params = struct(...
    ... file and path params;
    'workPath','.\temp\',...%working path;
    'OriVFName','.\data\video_orig.yuv',... full path and name for original video file, should be yuv (4:2:0) format;
    'TestVFName','.\data\video_dist.yuv',... full path and name for test video file;
    'interlaced',1,... 2 for interlaced content; 1 for progressive;
    'width', 768,...video frame width;
    'height', 432,...video frame height;
    'binPath','.\\bin\\',... the path of bin folder, which contains ;
    ... spatial and temporal cropping;
    'XLOffset',0,... offset for possible cropping
    'XROffset',0,...
    'YTOffset',0,...
    'YBOffset',0,...
    ... motion estimation
    'maxMV', 4, ...
    'maxMVPF',4, ...
    'mePrecision',4,...
    'mbSize',8,...
    'interval',8 ...
    ...
    );

if (exist(params.workPath,'dir') ==0)
    mkdir( params.workPath);
end

if (exist(params.TestVFName,'file') ~= 0 && exist(params.TestVFName,'file') ~= 0)
    d = dir(params.TestVFName);
    if( isfield( d, 'bytes' ) )
        params.noOfFrames = d.bytes/params.height/params.width/1.5;
        params.startF = 0;
    end
else
    error('Input files do not exist!');
end
