function res = inverse_dwt( approx, detail, me, params, map )

for c = 1 : 3
    if( exist('map', 'var') )
        mapr = map;

        basesize = size( detail{1, 1, 1} );
        basesize = basesize.*2;
        sm = size(map);
        
        if( ~params.dwtpermode )
            e = floor(abs((sm(1) - basesize(1)) /2));
            e2 = e;
        else
            e =0; e2 =0;
        end
        %e2 = ceil(abs((sm(1) - basesize(1)) /2));
        % dilate to keep some coeffs
        mapr = imerode(mapr, strel('square', params.filterlength));
    
        first = 1;
        for i = 1 : params.levels
        % rescale map to size of coeffs
            m = ones(basesize(1),basesize(2));

            %sm = size(mapr);
            if( ((rem(sm(1),2) ~= 0) || (rem(sm(2),2) ~= 0)) && first  )
                m( e+1:end-e2-1, e+1:end-e2-1) = mapr;
            else
                m( e+1:end-e2, e+1:end-e2) = mapr;
            end
        
            first = 0;
            %m( e+1:end-e2, e+1:end-e2) = mapr;
            mapr = m;
            if( ~params.dwtpermode )
                basesize = ceil(basesize./2) + params.filterlength-1;
            else
                basesize = ceil(basesize./2);
            end

            mapr = downsampleMap(mapr);
        
            for s = 1 : 3
                band = detail{i, c, s};
                band( mapr == 1 ) = 0;
                detail{i, c, s} = band;
            end
        end
    end
    
    % inverse
    for i = params.levels : -1 :1
        %for c = 1 : 3
            if( ~params.dwtpermode )
                approx{c} = idwt2(approx{c}, detail{i, c, 1}, detail{i, c, 2}, detail{i, c, 3}, params.filter);
            else
                approx{c} = idwt2(approx{c}, detail{i, c, 1}, detail{i, c, 2}, detail{i, c, 3}, params.filter,'mode','per');
            end
            %approxnq{c} = idwt2(approxnq{c}, data.horiznq{i, c}, data.vertnq{i, c}, data.diagnq{i, c}, data.filter);
            if ( i > 1 ) && ( size(approx{c}, 1) ~= size(detail{i-1,c,1}, 1) || size(approx{c}, 2) ~= size(detail{i-1,c,1}, 2) )
                [h,w] = size( detail{i-1,c,1} );
                approx{c} = approx{c}(1:h,1:w);
            end
        %end
    end
end


res(:,:,1) = approx{1};
res(:,:,2) = approx{2};
res(:,:,3) = approx{3};

for i=1:3
    res(:,:,i) = res(:,:,i) + me(i);
end

if( size(res, 1) > size(map,1) )
    res( end, :, : ) = [];
end
if( size(res, 1) < size(map,1) )
    res( end+1, :, : ) = res( end, :, : );
end
if( size(res, 2) > size(map,2) )
    res( :,end, : ) = [];
end
if( size(res, 2) < size(map,2) )
    res( :,end+1,: ) = res( :,end,: );
end


res = uint8(round(res));
res = ycbcr2rgb(res);

res = im2double(res);
return;

function res = downsampleMap(map)

[h,w] = size(map);
nw = round(w / 2);
nh = round(h / 2);

res = zeros(nh, nw);

    
for i = 1 : nw
    for j = 1 : nh
        x = floor((i - 1) * 2 + 1);
        y = floor((j - 1) * 2 + 1);
        ey = y + 1;
        ex = x + 1;
        if ey > h
            ey = y;
        end
        if ex > w
            ex = w;
        end
        parent = map(y:ey,x:ex);
        [ph,pw] = size(parent);
        if sum(parent(:)) == length(parent(:))
            res(j, i) = 1;
        else
            res(j,i) = 0;
        end
    end
end
return;

