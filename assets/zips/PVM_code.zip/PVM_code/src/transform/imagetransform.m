%function [ low, high, phase ] = imagetransform( image, Levels )
%function [ uphigh,high ] = imagetransform( image, Levels )
function [ uphigh,low] = imagetransform( image, Levels )
%IMAGETRANSFORM Summary of this function goes here
%   Detailed explanation goes here

imsize = size(image);
if( length(imsize) == 2)
  imsize(3) = 1;
end

% do wavelet decomposition
%Levels = 4;

% subband data for each level is stored as a 3D block 
% SUBBAND ORDER: degrees
sband_order = [15,45,75,-75,-45,-15 ];

[l_y(:,:),h_y_c] = dtwavexfm2(image(:,:,1),Levels,'antonini','qshift_06'); 
if( imsize(3) ~= 1)
  [l_cb(:,:),h_cb_c] = dtwavexfm2(image(:,:,2),Levels,'antonini','qshift_06');  
  [l_cr(:,:),h_cr_c] = dtwavexfm2(image(:,:,3),Levels,'antonini','qshift_06');  
end

% get magnitude and phase or our subbands
for n=1:Levels
  h_y{n} = abs( h_y_c{n} );
  %h_y_phase{n} = angle( h_y_c{n} );
  
  if( imsize(3) ~= 1)
    h_cb{n} = abs( h_cb_c{n} );
    h_cr{n} = abs( h_cr_c{n} );
    %h_cb_phase{n} = angle( h_cb_c{n} );
    %h_cr_phase{n} = angle( h_cr_c{n} );
  end
end
%{
% upsample
l_y_up = imresize(l_y, [imsize(1) imsize(2)], 'method','nearest');
if( imsize(3) ~= 1)
  l_cb_up = imresize(l_cb, [imsize(1) imsize(2)], 'method','nearest');
  l_cr_up = imresize(l_cr, [imsize(1) imsize(2)], 'method','nearest');
end

low(1) = {l_y_up};
if( imsize(3) ~= 1)
  low(2) = {l_cb_up};
  low(3) = {l_cr_up};
end
%}
uphigh = cell(Levels, 3, 6);
%high = cell(Levels, 3, 6);

for l=1:Levels   
  for s=1:6
    uphigh(l,1,s) = {imresize( h_y{l}(:,:,s), [imsize(1) imsize(2)], 'method','nearest') ./(2.^l)};
    %high(l,1,s) = {h_y_c{l}(:,:,s)};
    %h_y_phase_up{l}(:,:,s) = imresize( h_y_phase{l}(:,:,s), [imsize(1) imsize(2)], 'method','nearest');
    if( imsize(3) ~= 1)
      uphigh(l,2,s) = {imresize( h_cb{l}(:,:,s), [imsize(1) imsize(2)], 'method','nearest')./(2.^l)};
      uphigh(l,3,s) = {imresize( h_cr{l}(:,:,s), [imsize(1) imsize(2)], 'method','nearest')./(2.^l)};
      %high(l,2,s) = {h_cb_c{l}(:,:,s)};
      %high(l,3,s) = {h_cr_c{l}(:,:,s)};
      %h_cb_phase_up{l}(:,:,s) = imresize( h_cb_phase{l}(:,:,s), [imsize(1) imsize(2)], 'method','nearest');
      %h_cr_phase_up{l}(:,:,s) = imresize( h_cr_phase{l}(:,:,s), [imsize(1) imsize(2)], 'method','nearest');
    end
  end
end

low = {imresize( l_y, [imsize(1) imsize(2)], 'method','nearest') ./(2.^Levels)};
%{
high(1) = {h_y_up};
if( imsize(3) ~= 1)
  high(2) = {h_cb_up};
  high(3) = {h_cr_up};
end
%}
%{
phase(1) = {h_y_phase_up};
if( imsize(3) ~= 1)
  phase(2) = {h_cb_phase_up};
  phase(3) = {h_cr_phase_up};
end
%}