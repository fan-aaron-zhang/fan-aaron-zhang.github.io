function row = getAlignedStr(strarr, maxStrLength)

row = "";
for i = 1:length(strarr)
    row = row + padStr(strarr(i), maxStrLength);
%     if startsWith(strarr(i), "-")
%         row_charvec = convertStringsToChars(row);
%         row = string(row_charvec(1:end-1));
%     end
end
end

function numStr = padStr(numStr, maxStrLength)
interval = "";
for i=1:5-maxStrLength
    interval = interval + " ";
end

curStrLength = strlength(numStr);
if startsWith(numStr, '-')
%     curStrLength = curStrLength;
    numStr = " " + numStr;
end

for i=1:maxStrLength-curStrLength
    numStr = "  " + numStr;
end

numStr = numStr + interval;
end
